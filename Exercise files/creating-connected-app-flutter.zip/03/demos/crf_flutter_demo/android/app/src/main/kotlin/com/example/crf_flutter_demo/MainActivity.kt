package com.example.crf_flutter_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
