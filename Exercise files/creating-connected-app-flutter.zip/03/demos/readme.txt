To run the demos:
    - `pub get` in the crf_flutter_demo
    - `pip install -r requirements.txt` in the crf_service
    - `python init.py` in the crf_service