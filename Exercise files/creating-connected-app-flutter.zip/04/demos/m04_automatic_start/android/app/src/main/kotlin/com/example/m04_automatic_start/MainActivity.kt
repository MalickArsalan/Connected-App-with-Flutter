package com.example.m04_automatic_start

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
