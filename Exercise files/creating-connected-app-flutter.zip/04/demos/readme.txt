To run the demos:
    - `pub get` in the crf_flutter_demo