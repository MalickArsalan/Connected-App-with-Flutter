package com.example.m04_manual_start

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
