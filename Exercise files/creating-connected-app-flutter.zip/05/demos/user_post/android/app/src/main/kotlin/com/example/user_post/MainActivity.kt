package com.example.user_post

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
